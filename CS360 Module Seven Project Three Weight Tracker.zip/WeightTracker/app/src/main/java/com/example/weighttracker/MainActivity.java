package com.example.weighttracker;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    private DatabaseHelper databaseHelper;

    private EditText editUsername;
    private EditText editPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        // Initialize the SQLite database.
        databaseHelper = new DatabaseHelper(this);
        databaseHelper.getWritableDatabase();

        // Connect Java variables to the existing UI fields.
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);

        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnCreateAccount =
                findViewById(R.id.btnCreateAccount);

        // Authenticate an existing user.
        btnLogin.setOnClickListener(v -> loginUser());

        // Register a new user.
        btnCreateAccount.setOnClickListener(
                v -> createAccount()
        );
    }

    private void createAccount() {

        String username = editUsername.getText()
                .toString().trim();

        String password = editPassword.getText()
                .toString();

        // Both fields are required.
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please enter a username and password.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        // Apply basic password requirements.
        if (password.length() < 8) {
            Toast.makeText(
                    this,
                    "Password must contain at least 8 characters.",
                    Toast.LENGTH_LONG
            ).show();
            return;
        }

        // Prevent duplicate usernames.
        if (databaseHelper.getUserId(username) != -1) {
            Toast.makeText(
                    this,
                    "Username already exists.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        boolean success = databaseHelper.registerUser(
                username, password
        );

        if (success) {

            Toast.makeText(
                    this,
                    "Account created successfully! Please log in.",
                    Toast.LENGTH_LONG
            ).show();

            // Clear the password after registration.
            editPassword.setText("");

        } else {

            Toast.makeText(
                    this,
                    "Unable to create account.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private void loginUser() {

        String username = editUsername.getText()
                .toString().trim();

        String password = editPassword.getText()
                .toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please enter your username and password.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        // Check the submitted credentials against SQLite.
        boolean valid = databaseHelper.validateLogin(
                username, password
        );

        if (valid) {

            long userId = databaseHelper.getUserId(username);

            if (userId == -1) {
                Toast.makeText(
                        this,
                        "Unable to load user account.",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            Toast.makeText(
                    this,
                    "Login successful!",
                    Toast.LENGTH_SHORT
            ).show();

            // Pass the authenticated user's ID to the dashboard.
            Intent intent = new Intent(
                    MainActivity.this,
                    DashboardActivity.class
            );

            intent.putExtra("USER_ID", userId);

            startActivity(intent);

            // Remove the login screen from the back stack.
            finish();

        } else {

            Toast.makeText(
                    this,
                    "Invalid username or password.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
}
