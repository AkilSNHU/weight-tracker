package com.example.weighttracker;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.database.Cursor;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class AddWeightActivity extends Activity {

    private DatabaseHelper databaseHelper;
    private EditText editWeight;
    private EditText editDate;

    private long userId;
    private long weightId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        userId = getIntent().getLongExtra("USER_ID", -1);
        weightId = getIntent().getLongExtra("WEIGHT_ID", -1);

        if (userId <= 0) {
            Toast.makeText(this,
                    "Please log in first.",
                    Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        databaseHelper = new DatabaseHelper(this);

        editWeight = findViewById(R.id.editWeight);
        editDate = findViewById(R.id.editDate);

        Button btnSaveWeight =
                findViewById(R.id.btnSaveWeight);
        Button btnCancelWeight =
                findViewById(R.id.btnCancelWeight);

        // If editing, populate the existing record values.
        if (weightId > 0) {
            String existingDate = getIntent()
                    .getStringExtra("WEIGHT_DATE");

            double existingWeight = getIntent()
                    .getDoubleExtra("WEIGHT_VALUE", 0);

            editDate.setText(existingDate);
            editWeight.setText(
                    String.valueOf(existingWeight));

            btnSaveWeight.setText("Update Weight");
        } else {
            // Default new entries to today's date.
            editDate.setText(LocalDate.now().toString());
        }

        btnSaveWeight.setOnClickListener(v ->
                saveWeight());

        btnCancelWeight.setOnClickListener(v -> finish());
    }

    private void saveWeight() {

        String weightInput = editWeight.getText()
                .toString().trim();

        String dateInput = editDate.getText()
                .toString().trim();

        if (weightInput.isEmpty() || dateInput.isEmpty()) {
            Toast.makeText(this,
                    "Please enter a weight and date.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        double weight;

        try {
            weight = Double.parseDouble(weightInput);
        } catch (NumberFormatException e) {
            editWeight.setError("Enter a valid weight.");
            return;
        }

        if (!Double.isFinite(weight) || weight <= 0) {
            editWeight.setError(
                    "Weight must be greater than zero.");
            return;
        }

        // Use ISO dates so SQLite can sort them correctly.
        try {
            LocalDate.parse(dateInput);
        } catch (DateTimeParseException e) {
            editDate.setError(
                    "Use YYYY-MM-DD (example: 2026-10-22).");
            return;
        }


        boolean success;

        if (weightId > 0) {

            // Editing a record does not trigger an SMS.
            success = databaseHelper.updateWeight(
                    userId, weightId, dateInput, weight);

        } else {

            // Find the most recent existing measurement.
            Double previousWeight = null;

            try (Cursor cursor =
                         databaseHelper.getWeights(userId)) {

                if (cursor.moveToFirst()) {
                    previousWeight = cursor.getDouble(
                            cursor.getColumnIndexOrThrow("weight")
                    );
                }
            }

            // Insert the new measurement.
            long newId = databaseHelper.addWeight(
                    userId, dateInput, weight);

            success = newId != -1;

            if (success) {

                // Send only for a new, latest-date measurement.
                // This avoids alerts from backdated entries.
                boolean isLatestEntry = true;

                try (Cursor cursor =
                             databaseHelper.getWeights(userId)) {

                    if (cursor.moveToFirst()) {
                        long latestId = cursor.getLong(
                                cursor.getColumnIndexOrThrow("_id")
                        );

                        isLatestEntry = latestId == newId;
                    }
                }

                if (isLatestEntry) {
                    checkGoalNotification(previousWeight, weight);
                }
            }
        }


        if (success) {

            Toast.makeText(this,
                    weightId > 0
                            ? "Weight record updated."
                            : "Weight record saved.",
                    Toast.LENGTH_SHORT).show();

            finish();

        } else {

            Toast.makeText(this,
                    "Unable to save weight record.",
                    Toast.LENGTH_SHORT).show();
        }
    }


    private void checkGoalNotification(
            Double previousWeight,
            double newWeight) {

        Double goal = databaseHelper.getGoal(userId);

        // A goal must exist before an alert can be triggered.
        if (goal == null) {
            return;
        }

        // Only alert when crossing from above the goal
        // to the goal or below it.
        boolean crossedGoal =
                previousWeight != null
                        && previousWeight > goal
                        && newWeight <= goal;

        if (!crossedGoal) {
            return;
        }

        String phoneNumber =
                databaseHelper.getPhoneNumber(userId);

        boolean submitted =
                SmsNotificationHelper.sendGoalAlert(
                        this,
                        phoneNumber,
                        newWeight,
                        goal
                );

        if (submitted) {
            Toast.makeText(
                    this,
                    "Goal reached! SMS send requested.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
}
