
package com.example.weighttracker;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.util.Log;

import java.util.Locale;

public class SmsNotificationHelper {

    private static final String TAG = "WeightTrackerSMS";

    // Attempt to send an alert only when SMS is authorized.
    public static boolean sendGoalAlert(
            Context context,
            String phoneNumber,
            double currentWeight,
            double goalWeight) {

        if (phoneNumber == null ||
                !phoneNumber.matches("\\+[1-9][0-9]{7,14}")) {
            return false;
        }

        // Never send SMS without the required permission.
        if (context.checkSelfPermission(
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            Log.d(TAG, "SMS permission not granted.");
            return false;
        }

        String message = String.format(
                Locale.US,
                "WeightTracker: Congratulations! " +
                        "You reached your goal of %.1f lbs. " +
                        "Your recorded weight is %.1f lbs.",
                goalWeight,
                currentWeight
        );

        try {
            // Uses the device's default SMS subscription.
            SmsManager smsManager = SmsManager.getDefault();

            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    message,
                    null,
                    null
            );

            Log.d(TAG, "SMS send request submitted.");
            return true;

        } catch (Exception e) {

            Log.e(TAG, "Unable to submit SMS.", e);
            return false;
        }
    }
}
