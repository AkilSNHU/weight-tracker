package com.example.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int DATABASE_VERSION = 2;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_WEIGHTS = "weights";
    private static final String TABLE_GOALS = "goals";

    private static final int HASH_ITERATIONS = 120000;
    private static final int HASH_BITS = 256;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Store user accounts and password verification data.
        db.execSQL(
                "CREATE TABLE users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT NOT NULL UNIQUE, " +
                        "password_hash TEXT NOT NULL, " +
                        "password_salt TEXT NOT NULL, " +
                        "phone_number TEXT)"
        );

        // Store daily weight measurements for each user.
        db.execSQL(
                "CREATE TABLE weights (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER NOT NULL, " +
                        "date TEXT NOT NULL, " +
                        "weight REAL NOT NULL CHECK(weight > 0), " +
                        "FOREIGN KEY(user_id) REFERENCES users(id) " +
                        "ON DELETE CASCADE)"
        );

        // Each user has at most one current goal weight.
        db.execSQL(
                "CREATE TABLE goals (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER NOT NULL UNIQUE, " +
                        "goal_weight REAL NOT NULL " +
                        "CHECK(goal_weight > 0), " +
                        "FOREIGN KEY(user_id) REFERENCES users(id) " +
                        "ON DELETE CASCADE)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion,
                          int newVersion) {

        // Preserve existing accounts and records.
        if (oldVersion < 2) {
            db.execSQL(
                    "ALTER TABLE users ADD COLUMN phone_number TEXT"
            );
        }
    }
    // Generate random salt bytes for a new account.
    private byte[] generateSalt() {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        return salt;
    }

    private String toHex(byte[] bytes) {
        StringBuilder result = new StringBuilder();

        for (byte value : bytes) {
            result.append(String.format("%02x", value & 0xff));
        }

        return result.toString();
    }

    private byte[] fromHex(String hex) {
        if (hex.length() % 2 != 0) {
            throw new IllegalArgumentException("Invalid hex");
        }

        byte[] result = new byte[hex.length() / 2];

        for (int i = 0; i < result.length; i++) {
            int index = i * 2;
            int value = Character.digit(hex.charAt(index), 16) * 16
                    + Character.digit(hex.charAt(index + 1), 16);

            if (value < 0) {
                throw new IllegalArgumentException("Invalid hex");
            }

            result[i] = (byte) value;
        }

        return result;
    }

    // Derive a password hash using PBKDF2.
    private byte[] hashPassword(char[] password, byte[] salt) {
        PBEKeySpec spec = new PBEKeySpec(
                password, salt, HASH_ITERATIONS, HASH_BITS);

        try {
            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance(
                            "PBKDF2WithHmacSHA256");

            return factory.generateSecret(spec).getEncoded();

        } catch (Exception e) {
            throw new IllegalStateException(
                    "Password hashing failed", e);
        } finally {
            spec.clearPassword();
        }
    }

    // Register a new user. Returns false for duplicate usernames.
    public boolean registerUser(String username, String password) {
        username = username.trim();

        if (username.isEmpty() || password.isEmpty()) {
            return false;
        }

        if (getUserId(username) != -1) {
            return false;
        }

        byte[] salt = generateSalt();
        char[] passwordChars = password.toCharArray();

        byte[] hash;

        try {
            hash = hashPassword(passwordChars, salt);
        } finally {
            Arrays.fill(passwordChars, '\0');
        }

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password_hash", toHex(hash));
        values.put("password_salt", toHex(salt));

        long result = getWritableDatabase().insert(
                TABLE_USERS, null, values);

        return result != -1;
    }

    // Return the account ID or -1 if the username is unknown.
    public long getUserId(String username) {
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_USERS,
                new String[]{"id"},
                "username = ?",
                new String[]{username.trim()},
                null, null, null)) {

            if (cursor.moveToFirst()) {
                return cursor.getLong(0);
            }
        }

        return -1;
    }

    // Verify a username/password pair.
    public boolean validateLogin(String username, String password) {
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_USERS,
                new String[]{"password_hash", "password_salt"},
                "username = ?",
                new String[]{username.trim()},
                null, null, null)) {

            if (!cursor.moveToFirst()) {
                return false;
            }

            byte[] expected = fromHex(cursor.getString(0));
            byte[] salt = fromHex(cursor.getString(1));

            char[] passwordChars = password.toCharArray();
            byte[] actual;

            try {
                actual = hashPassword(passwordChars, salt);
            } finally {
                Arrays.fill(passwordChars, '\0');
            }

            return MessageDigest.isEqual(expected, actual);
        }
    }

    // CREATE: Add a daily weight record.
    public long addWeight(long userId, String date, double weight) {
        if (userId <= 0 || date == null ||
                date.trim().isEmpty() ||
                !Double.isFinite(weight) || weight <= 0) {
            return -1;
        }

        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("date", date.trim());
        values.put("weight", weight);

        return getWritableDatabase().insert(
                TABLE_WEIGHTS, null, values);
    }

    // READ: Return a user's records, newest first.
    // The caller must close the returned Cursor.
    public Cursor getWeights(long userId) {
        return getReadableDatabase().query(
                TABLE_WEIGHTS,
                new String[]{"id AS _id", "date", "weight"},
                "user_id = ?",
                new String[]{String.valueOf(userId)},
                null, null,
                "date DESC, id DESC");
    }

    // UPDATE: Change an existing weight record.
    public boolean updateWeight(long userId, long weightId,
                                String date, double weight) {
        if (userId <= 0 || weightId <= 0 ||
                date == null || date.trim().isEmpty() ||
                !Double.isFinite(weight) || weight <= 0) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put("date", date.trim());
        values.put("weight", weight);

        int rows = getWritableDatabase().update(
                TABLE_WEIGHTS,
                values,
                "id = ? AND user_id = ?",
                new String[]{
                        String.valueOf(weightId),
                        String.valueOf(userId)
                });

        return rows > 0;
    }

    // DELETE: Remove a weight record belonging to the user.
    public boolean deleteWeight(long userId, long weightId) {
        int rows = getWritableDatabase().delete(
                TABLE_WEIGHTS,
                "id = ? AND user_id = ?",
                new String[]{
                        String.valueOf(weightId),
                        String.valueOf(userId)
                });

        return rows > 0;
    }

    // CREATE/UPDATE: Store the user's current goal weight.
    public boolean saveGoal(long userId, double goalWeight) {
        if (userId <= 0 || !Double.isFinite(goalWeight)
                || goalWeight <= 0) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("goal_weight", goalWeight);

        long result = getWritableDatabase().insertWithOnConflict(
                TABLE_GOALS,
                null,
                values,
                SQLiteDatabase.CONFLICT_REPLACE);

        return result != -1;
    }

    // READ: Return the goal, or null if none has been set.
    public Double getGoal(long userId) {
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_GOALS,
                new String[]{"goal_weight"},
                "user_id = ?",
                new String[]{String.valueOf(userId)},
                null, null, null)) {

            if (cursor.moveToFirst()) {
                return cursor.getDouble(0);
            }
        }

        return null;
    }


    // Save the SMS destination for a specific user.
    public boolean savePhoneNumber(long userId, String phoneNumber) {

        if (userId <= 0 || phoneNumber == null) {
            return false;
        }

        String number = phoneNumber.trim();

        // Require international format, such as +15551234567.
        if (!number.matches("\\+[1-9][0-9]{7,14}")) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put("phone_number", number);

        int rows = getWritableDatabase().update(
                TABLE_USERS,
                values,
                "id = ?",
                new String[]{String.valueOf(userId)}
        );

        return rows > 0;
    }

    // Retrieve the user's saved SMS destination.
    public String getPhoneNumber(long userId) {

        try (Cursor cursor = getReadableDatabase().query(
                TABLE_USERS,
                new String[]{"phone_number"},
                "id = ?",
                new String[]{String.valueOf(userId)},
                null, null, null)) {

            if (cursor.moveToFirst()) {
                return cursor.getString(0);
            }
        }

        return null;
    }

}
