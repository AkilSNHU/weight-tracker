package com.example.weighttracker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import java.util.Locale;

public class DashboardActivity extends Activity {

    private long userId;
    private DatabaseHelper databaseHelper;
    private TableLayout tableWeights;
    private TextView textDashboardGoal;
    private ProgressBar progressGoal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        userId = getIntent().getLongExtra("USER_ID", -1);

        if (userId <= 0) {
            Toast.makeText(this,
                    "Please log in to continue.",
                    Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        databaseHelper = new DatabaseHelper(this);
        tableWeights = findViewById(R.id.tableWeights);

        textDashboardGoal =
                findViewById(R.id.textDashboardGoal);

        progressGoal =
                findViewById(R.id.progressGoal);

        progressGoal.setMax(100);

        Button btnAddWeight = findViewById(R.id.btnAddWeight);
        Button btnSetGoal = findViewById(R.id.btnSetGoal);
        Button btnNotifications =
                findViewById(R.id.btnNotifications);

        btnAddWeight.setOnClickListener(v -> {
            Intent intent = new Intent(
                    this, AddWeightActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });

        btnSetGoal.setOnClickListener(v -> {
            Intent intent = new Intent(
                    this, GoalWeightActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });

        btnNotifications.setOnClickListener(v -> {
            Intent intent = new Intent(
                    this, SmsSettingsActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (databaseHelper != null) {
            loadWeightRecords();
            loadGoalProgress();
        }
    }

    // Read the user's saved weights and build the grid.
    private void loadWeightRecords() {

        // Keep the header row; remove old data rows.
        if (tableWeights.getChildCount() > 1) {
            tableWeights.removeViews(
                    1, tableWeights.getChildCount() - 1);
        }

        try (Cursor cursor = databaseHelper.getWeights(userId)) {

            int idColumn = cursor.getColumnIndexOrThrow("_id");
            int dateColumn =
                    cursor.getColumnIndexOrThrow("date");
            int weightColumn =
                    cursor.getColumnIndexOrThrow("weight");

            if (cursor.getCount() == 0) {
                TableRow emptyRow = new TableRow(this);

                TextView emptyText = new TextView(this);
                emptyText.setText(
                        "No weight records yet. Add your first entry.");
                emptyText.setPadding(12, 24, 12, 24);
                emptyText.setTextColor(0xFF607D8B);

                emptyRow.addView(emptyText,
                        new TableRow.LayoutParams(0));
                tableWeights.addView(emptyRow);
                return;
            }

            while (cursor.moveToNext()) {

                long recordId = cursor.getLong(idColumn);
                String date = cursor.getString(dateColumn);
                double weight = cursor.getDouble(weightColumn);

                addWeightRow(recordId, date, weight);
            }
        }
    }

    // Create one table row for a saved measurement.
    private void addWeightRow(
            long recordId, String date, double weight) {

        TableRow row = new TableRow(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(4, 8, 4, 8);

        TextView dateText = new TextView(this);
        dateText.setText(date);
        dateText.setTextColor(0xFF234E70);
        dateText.setPadding(4, 8, 4, 8);
        row.addView(dateText);

        TextView weightText = new TextView(this);
        weightText.setText(String.format(
                Locale.US, "%.1f lbs", weight));
        weightText.setTextColor(0xFF234E70);
        weightText.setPadding(4, 8, 4, 8);
        row.addView(weightText);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.VERTICAL);

        Button btnEdit = new Button(this);
        btnEdit.setText("Edit");
        btnEdit.setTextSize(12);
        btnEdit.setAllCaps(false);

        Button btnDelete = new Button(this);
        btnDelete.setText("Delete");
        btnDelete.setTextSize(12);
        btnDelete.setAllCaps(false);

        actions.addView(btnEdit,
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));

        actions.addView(btnDelete,
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));

        row.addView(actions);
        tableWeights.addView(row);

        btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(
                    this, AddWeightActivity.class);

            intent.putExtra("USER_ID", userId);
            intent.putExtra("WEIGHT_ID", recordId);
            intent.putExtra("WEIGHT_DATE", date);
            intent.putExtra("WEIGHT_VALUE", weight);

            startActivity(intent);
        });

        btnDelete.setOnClickListener(v ->
                confirmDelete(recordId));
    }

    // Require confirmation before deleting a record.
    private void confirmDelete(long recordId) {

        new AlertDialog.Builder(this)
                .setTitle("Delete Weight Record")
                .setMessage(
                        "Are you sure you want to delete this entry?")
                .setPositiveButton("Delete", (dialog, which) -> {

                    boolean deleted =
                            databaseHelper.deleteWeight(
                                    userId, recordId);

                    if (deleted) {
                        Toast.makeText(this,
                                "Weight record deleted.",
                                Toast.LENGTH_SHORT).show();
                        loadWeightRecords();
                        loadGoalProgress();
                    } else {
                        Toast.makeText(this,
                                "Unable to delete record.",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }


    private void loadGoalProgress() {

        // Retrieve the user's saved goal weight.
        Double goalWeight = databaseHelper.getGoal(userId);

        if (goalWeight == null) {

            textDashboardGoal.setText("No goal set");
            progressGoal.setProgress(0);
            return;
        }

        textDashboardGoal.setText(String.format(
                Locale.US, "%.1f lbs", goalWeight));

        // Find the user's most recent recorded weight.
        Double currentWeight = null;

        try (Cursor cursor = databaseHelper.getWeights(userId)) {

            int weightColumn =
                    cursor.getColumnIndexOrThrow("weight");

            if (cursor.moveToFirst()) {
                currentWeight = cursor.getDouble(weightColumn);
            }
        }

        if (currentWeight == null) {
            progressGoal.setProgress(0);
            return;
        }


        boolean goalReached = currentWeight <= goalWeight;

        // Until a starting weight is recorded, show goal status
        // rather than an inaccurate progress percentage.
        progressGoal.setProgress(goalReached ? 100 : 0);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
}
