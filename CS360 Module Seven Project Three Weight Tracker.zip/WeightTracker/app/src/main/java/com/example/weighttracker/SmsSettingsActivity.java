package com.example.weighttracker;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.EditText;

public class SmsSettingsActivity extends Activity {

    private static final int SMS_PERMISSION_CODE = 100;

    private TextView textPermissionStatus;
    private Button btnRequestSms;

    private DatabaseHelper databaseHelper;
    private EditText editPhoneNumber;
    private long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_sms_settings);


        userId = getIntent().getLongExtra("USER_ID", -1);

        if (userId <= 0) {
            Toast.makeText(this,
                    "Please log in first.",
                    Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        databaseHelper = new DatabaseHelper(this);

        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        Button btnSavePhone = findViewById(R.id.btnSavePhone);

        // Load the user's previously saved phone number.
        String savedNumber = databaseHelper.getPhoneNumber(userId);

        if (savedNumber != null) {
            editPhoneNumber.setText(savedNumber);
        }

        btnSavePhone.setOnClickListener(v -> {

            String number = editPhoneNumber.getText()
                    .toString().trim();

            if (!number.matches("\\+[1-9][0-9]{7,14}")) {
                editPhoneNumber.setError(
                        "Enter a number such as +15551234567.");
                return;
            }

            boolean saved = databaseHelper.savePhoneNumber(
                    userId, number);

            Toast.makeText(
                    this,
                    saved ? "Phone number saved."
                            : "Unable to save phone number.",
                    Toast.LENGTH_SHORT
            ).show();
        });


        textPermissionStatus =
                findViewById(R.id.textPermissionStatus);

        btnRequestSms =
                findViewById(R.id.btnRequestSms);

        Button btnBackDashboard =
                findViewById(R.id.btnBackDashboard);

        updatePermissionStatus();

        btnRequestSms.setOnClickListener(v -> {

            if (checkSelfPermission(
                    Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(
                        this,
                        "SMS permission already granted.",
                        Toast.LENGTH_SHORT
                ).show();

            } else {

                requestPermissions(
                        new String[]{
                                Manifest.permission.SEND_SMS
                        },
                        SMS_PERMISSION_CODE
                );
            }
        });

        btnBackDashboard.setOnClickListener(
                v -> finish()
        );
    }

    private void updatePermissionStatus() {

        boolean granted = checkSelfPermission(
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED;

        if (granted) {

            textPermissionStatus.setText(
                    "Permission Granted"
            );

            textPermissionStatus.setTextColor(
                    0xFF2E7D32
            );

            btnRequestSms.setText(
                    "SMS Permission Enabled"
            );

        } else {

            textPermissionStatus.setText(
                    "Permission Not Granted"
            );

            textPermissionStatus.setTextColor(
                    0xFFB94A48
            );

            btnRequestSms.setText(
                    "Enable SMS Notifications"
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (requestCode == SMS_PERMISSION_CODE) {

            boolean granted =
                    grantResults.length > 0
                            && grantResults[0]
                            == PackageManager.PERMISSION_GRANTED;

            if (granted) {

                Toast.makeText(
                        this,
                        "SMS permission granted.",
                        Toast.LENGTH_SHORT
                ).show();

            } else {

                Toast.makeText(
                        this,
                        "SMS notifications will remain disabled.",
                        Toast.LENGTH_LONG
                ).show();
            }

            updatePermissionStatus();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionStatus();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
}
