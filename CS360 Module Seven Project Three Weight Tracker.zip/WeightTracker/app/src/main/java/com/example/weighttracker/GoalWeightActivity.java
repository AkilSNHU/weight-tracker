
package com.example.weighttracker;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class GoalWeightActivity extends Activity {

    private DatabaseHelper databaseHelper;
    private EditText editGoalWeight;
    private TextView textCurrentGoal;

    private long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_weight);

        // Identify the currently logged-in user.
        userId = getIntent().getLongExtra("USER_ID", -1);

        if (userId <= 0) {
            Toast.makeText(this,
                    "Please log in first.",
                    Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        databaseHelper = new DatabaseHelper(this);

        editGoalWeight = findViewById(R.id.editGoalWeight);
        textCurrentGoal = findViewById(R.id.textCurrentGoal);

        Button btnSaveGoal =
                findViewById(R.id.btnSaveGoal);
        Button btnCancelGoal =
                findViewById(R.id.btnCancelGoal);

        // Load the user's previously saved goal.
        loadCurrentGoal();

        btnSaveGoal.setOnClickListener(v -> saveGoal());

        btnCancelGoal.setOnClickListener(v -> finish());
    }

    private void loadCurrentGoal() {

        Double savedGoal = databaseHelper.getGoal(userId);

        if (savedGoal != null) {

            textCurrentGoal.setText(String.format(
                    Locale.US, "%.1f lbs", savedGoal));

            editGoalWeight.setText(
                    String.valueOf(savedGoal));

        } else {

            textCurrentGoal.setText("No goal set");

            editGoalWeight.setText("");
        }
    }

    private void saveGoal() {

        String input = editGoalWeight.getText()
                .toString().trim();

        if (input.isEmpty()) {
            editGoalWeight.setError(
                    "Please enter a goal weight.");
            return;
        }

        double goalWeight;

        try {
            goalWeight = Double.parseDouble(input);
        } catch (NumberFormatException e) {
            editGoalWeight.setError(
                    "Enter a valid number.");
            return;
        }

        if (!Double.isFinite(goalWeight) || goalWeight <= 0) {
            editGoalWeight.setError(
                    "Goal weight must be greater than zero.");
            return;
        }

        // Persist the user's goal weight in SQLite.
        boolean saved = databaseHelper.saveGoal(
                userId, goalWeight);

        if (saved) {

            textCurrentGoal.setText(String.format(
                    Locale.US, "%.1f lbs", goalWeight));

            Toast.makeText(this,
                    "Goal weight saved successfully.",
                    Toast.LENGTH_SHORT).show();

            finish();

        } else {

            Toast.makeText(this,
                    "Unable to save goal weight.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
}
